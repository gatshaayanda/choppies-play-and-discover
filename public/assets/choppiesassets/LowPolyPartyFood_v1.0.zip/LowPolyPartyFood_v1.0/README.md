# Low Poly Party Food & Snacks Pack - Free 3D Assets (Free)
by reodesuxz

28 low poly party food, snack and drink models for games

## Contents
- FBX/  - one .fbx per model (Unity, Unreal, Godot, Blender)
- GLB/  - one .glb per model (Godot, three.js, Babylon.js, web)
- OBJ/  - one .obj + .mtl per model
- PartyFood_AllAssets.blend - every model in one Blender file (Blender 4.3+)

## Specs
- Total: 4512 triangles for all 27 models (20-416 tris each)
- Flat-shaded, simple shared materials (no textures needed)
- Real-world scale in metres, pivot at the base centre

| Model | Category | Tris | Size (cm) |
|---|---|---|---|
| burger | Fast Food | 244 | 14 x 14 x 13 |
| hot_dog | Fast Food | 52 | 20 x 5 x 6 |
| pizza_slice | Fast Food | 128 | 14 x 20 x 2 |
| fries_box | Fast Food | 120 | 8 x 3 x 17 |
| soda_cup | Fast Food | 140 | 9 x 9 x 20 |
| nachos | Fast Food | 128 | 19 x 20 x 6 |
| taco | Fast Food | 120 | 12 x 11 x 7 |
| chicken_wings_bucket | Fast Food | 268 | 18 x 18 x 20 |
| popcorn_bucket | Snacks | 328 | 16 x 16 x 21 |
| chips_bag | Snacks | 40 | 15 x 5 x 22 |
| pretzel | Snacks | 220 | 15 x 12 x 3 |
| chip_dip_bowl | Snacks | 200 | 15 x 15 x 7 |
| salsa_jar | Snacks | 108 | 8 x 8 x 12 |
| candy_corn | Snacks | 20 | 5 x 4 x 8 |
| sausage_skewer | Snacks | 128 | 4 x 4 x 25 |
| birthday_cake | Sweets | 348 | 24 x 25 x 17 |
| cupcake | Sweets | 90 | 7 x 7 x 12 |
| donut | Sweets | 336 | 11 x 11 x 3 |
| ice_cream_cone | Sweets | 88 | 6 x 6 x 21 |
| cookie_plate | Sweets | 276 | 23 x 24 x 4 |
| chocolate_fountain | Sweets | 188 | 24 x 24 x 25 |
| punch_bowl | Drinks | 416 | 34 x 34 x 16 |
| party_cup_stack | Drinks | 108 | 7 x 7 x 19 |
| champagne_bottle | Drinks | 136 | 8 x 8 x 34 |
| party_table | Party Setup | 104 | 162 x 82 x 77 |
| snack_stand | Party Setup | 70 | 150 x 150 x 210 |
| balloon_bunch | Party Setup | 108 | 41 x 24 x 84 |

## License
See LICENSE.txt. Free to use in unlimited personal and commercial projects. You may not resell or redistribute the models themselves.
If this pack helped you, a small tip on itch.io keeps more free packs coming. Thank you!
