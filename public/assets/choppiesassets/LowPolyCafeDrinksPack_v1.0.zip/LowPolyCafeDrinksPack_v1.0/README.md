# Low Poly Cafe Drinks & Pastries Pack (Free)
by reodesuxz

29 low poly cafe models: coffee and tea drinks, brewing gear, pastries and counter props.

## Contents
- FBX/  - one .fbx per model (Unity, Unreal, Godot, Blender)
- GLB/  - one .glb per model (Godot, three.js, Babylon.js, web)
- OBJ/  - one .obj + .mtl per model
- CafeDrinks_AllAssets.blend - every model in one Blender file (Blender 4.3+)

## Specs
- Total: 4910 triangles for all 29 models (24-504 tris each)
- Flat-shaded, simple shared materials (no textures needed)
- Real-world scale in metres, pivot at the base centre

| Model | Category | Tris | Size (cm) |
|---|---|---|---|
| takeaway_cup | Cups | 108 | 9 x 10 x 14 |
| iced_latte | Cups | 124 | 8 x 8 x 21 |
| espresso_cup | Cups | 284 | 12 x 10 x 5 |
| latte_glass | Cups | 108 | 9 x 9 x 12 |
| cappuccino_bowl | Cups | 152 | 14 x 14 x 8 |
| teacup_saucer | Cups | 284 | 14 x 14 x 6 |
| bubble_tea | Cups | 204 | 9 x 9 x 25 |
| smoothie_glass | Cups | 108 | 10 x 9 x 24 |
| matcha_latte | Cups | 108 | 9 x 9 x 11 |
| hot_chocolate_mug | Cups | 264 | 13 x 8 x 11 |
| moka_pot | Equipment | 96 | 16 x 12 x 22 |
| french_press | Equipment | 312 | 14 x 10 x 32 |
| pour_over_dripper | Equipment | 120 | 14 x 12 x 17 |
| kettle_gooseneck | Equipment | 260 | 23 x 16 x 25 |
| milk_jug | Equipment | 210 | 12 x 10 x 11 |
| sugar_dispenser | Equipment | 128 | 9 x 9 x 15 |
| coffee_bean_jar | Equipment | 108 | 14 x 14 x 21 |
| cheesecake_slice | Pastries | 36 | 10 x 12 x 5 |
| macaron_stack | Pastries | 216 | 7 x 7 x 7 |
| muffin | Pastries | 88 | 9 x 9 x 11 |
| cinnamon_roll | Pastries | 424 | 12 x 12 x 5 |
| eclair | Pastries | 36 | 14 x 5 x 5 |
| cookie_plate | Pastries | 196 | 27 x 28 x 4 |
| scone_jam | Pastries | 92 | 14 x 14 x 7 |
| pretzel_twist | Pastries | 504 | 15 x 12 x 2 |
| menu_stand | Cafe Props | 36 | 30 x 20 x 40 |
| serving_tray | Cafe Props | 60 | 41 x 29 x 5 |
| napkin_holder | Cafe Props | 24 | 10 x 6 x 14 |
| cake_dome | Cafe Props | 220 | 25 x 26 x 18 |

## License
See LICENSE.txt. Free to use in unlimited personal and commercial projects. You may not resell or redistribute the models themselves.
If this pack helped you, a small tip on itch.io keeps more free packs coming. Thank you!
